#ifndef SIMULATION_H
#define SIMULATION_H


class simulation
{
public:
    simulation();
};

#endif // SIMULATION_H
