#ifndef WORLD_H
#define WORLD_H


class world
{
public:
    world();
};

#endif // WORLD_H
