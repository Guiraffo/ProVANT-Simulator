#ifndef WORLDPLUGIN_H
#define WORLDPLUGIN_H
#include "plugin_da.h"

class WorldPlugin : public plugin_DA
{
public:
    WorldPlugin();
};

#endif // WORLDPLUGIN_H
