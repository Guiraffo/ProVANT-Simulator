#include "worldplugin.h"

WorldPlugin::WorldPlugin()
{

}

