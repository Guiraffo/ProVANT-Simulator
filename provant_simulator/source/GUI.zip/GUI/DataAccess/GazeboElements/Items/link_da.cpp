#include "link_da.h"

link_DA::link_DA()
{

}

bool link_DA::Read(QDomNode* document)
{
    static bool i = 1;
    if(i==1){
        i = 0;
        *document = document->firstChildElement("link");
    }
    else
    {
        *document = document->nextSiblingElement("link");
    }
    if(document->isNull())
    {
        return true;
    }
    name = document->toElement().attribute("name")
                   .toStdString();

    pose = document->firstChildElement("pose")
                   .text()
                   .toStdString();

    inertialValues.Read(*document);
    collision.Read(*document);
    visual.Read(*document);
    return false;

}

void link_DA::Write(QXmlStreamWriter* xml)
{
    xml->writeStartElement("link");
    xml->writeAttribute("name",name.c_str());
    xml->writeTextElement("pose",pose.c_str());
    inertialValues.Write(xml);
    collision.Write(xml);
    visual.Write(xml);
    xml->writeEndElement();
}

void link_DA::print()
{
    qDebug() << "Link";
    qDebug() << "Name: " << name.c_str();
    qDebug() << "Pose: " << pose.c_str();
    inertialValues.print();
    collision.print();
    visual.print();
}

