#ifndef LINK_DA_H
#define LINK_DA_H
#include"string"
#include"inertial.h"
#include"collision.h"
#include"visual.h"

class link_DA
{
public:
    link_DA();
    bool Read(QDomNode*);
    void Write(QXmlStreamWriter*);
    void print();

    std::string name;
    std::string pose;
    Inertial inertialValues;
    Visual visual;
    Collision collision;

};

#endif // LINK_DA_H
