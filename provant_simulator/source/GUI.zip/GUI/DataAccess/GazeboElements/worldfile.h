#ifndef WORLDFILE_H
#define WORLDFILE_H

#include"Items/gravity_da.h"
#include"Items/include_da.h"
#include"Items/physics_da.h"
#include"Items/worldplugin.h"


class WorldFile
{
public:
    WorldFile(std::string);
    gravity_DA GetGravity();
    void SetGravity(gravity_DA);
    physics_DA GetPhysics();
    void SetPhysics(physics_DA);
    WorldPlugin GetPlugin();
    void SetPlugin(WorldPlugin);
    std::vector<Include_DA>GetListsInclude();
    void AddInclude(Include_DA,int);
    void DeleteInclude(int i);
    void Read();
    void Write();
    void print();
private:
    std::string sdfVersion;
    QDomDocument doc;
    std::string Filename;
    QFile file;
    gravity_DA g;
    physics_DA physics;
    WorldPlugin plugin;
    std::vector<Include_DA> ListsInclude;
};

#endif // WORLDFILE_H
