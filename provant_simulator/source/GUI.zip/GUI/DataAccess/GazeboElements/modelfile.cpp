#include "modelfile.h"

ModelFile::ModelFile(std::string value):file(value.c_str())
{
    filename = value;
}

void ModelFile::Read()
{
    if(file.open(QIODevice::ReadOnly | QIODevice::Text))
    {
        QString erro;
        int line, column;
        if(doc.setContent(&file,&erro,&line,&column))
        {
            file.close();

            sdfVersion = doc.firstChildElement("sdf")
                            .attribute("version")
                            .toStdString();

            QDomNode itens = doc.firstChildElement("sdf");

            model.Read(itens);
        }
        else
        {
            if (erro == "unexpected end of file")
            {
                qDebug() << "Arquivo Vazio";
            }
            else
            {
                qDebug()<< "Problemas com conteudo" << erro;
                qDebug("Linha %d",line);
                qDebug("Coluna %d",column);
                file.close();
                exit(1);
            }
        }
    }
    else
    {
        // TO DO: criar exceção
        qDebug("Problemas com o arquivo xml");
        file.close();
        exit(1);
    }
    file.close();
}

void ModelFile::Write()
{
    if(file.open(QIODevice::ReadWrite|QIODevice::Truncate))
    {
        QXmlStreamWriter xml;
        xml.setAutoFormatting(true);
        xml.setDevice(&file);
        xml.writeStartDocument();
        xml.writeStartElement("sdf");
        xml.writeAttribute("version",sdfVersion.c_str());
        model.Write(&xml);
        xml.writeEndDocument();
    }
    else
    {
        // TO DO: criar exceção
        qDebug("Problemas com o arquivo xml");
        file.close();
        exit(1);
    }
    file.close();
}

void ModelFile::print()
{
    qDebug() << "ModelFile";
    qDebug() << "filename " << filename.c_str();
    model.print();
}

