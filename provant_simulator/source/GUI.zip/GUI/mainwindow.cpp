#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "QApplication"
#include "QDesktopWidget"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    //this->setFixedSize(QApplication::desktop()->screenGeometry().width(),
                       //QApplication::desktop()->screenGeometry().height());
    //this->showMaximized();
    //ui->horizontalLayoutWidget->adjustSize();
}

MainWindow::~MainWindow()
{
    delete ui;
}
