#include "mainwindow.h"
#include <QApplication>
#include"DataAccess/GazeboElements/modelfile.h"
#include"DataAccess/GazeboElements/worldfile.h"


int main(int argc, char *argv[])
{
    /*QApplication a(argc, argv);
    MainWindow w;
    w.show();
    return a.exec();*/
    /*ModelFile teste("/home/macro/catkin_ws/src/provant_simulator/source/Database/Models/vant_2comcarga/robot/teste.sdf");
    teste.Read();
    teste.print();
    teste.Write();*/

    WorldFile teste("/home/macro/catkin_ws/src/provant_simulator/source/Database/Scenery/empty/worlds/teste.world");
    teste.Read();
    teste.print();
    teste.Write();

    return 0;
}
